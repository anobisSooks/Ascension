﻿using System;
using System.Collections.Generic;
using Verse;
using RimWorld;

namespace Ascension
{
    // Token: 0x02000BDC RID: 3036
    public class IngestionOutcomeDoer_GiveHediffFromQuality : IngestionOutcomeDoer
    {
        // Token: 0x06004AB1 RID: 19121 RVA: 0x0019BA9C File Offset: 0x00199C9C
        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested)
        {
            Hediff hediff = HediffMaker.MakeHediff(this.hediffDef, pawn, null);
            float num;
            num = this.severity;
            if (this.severity > 0f)
            {
                QualityCategory qc = new QualityCategory();
                QualityUtility.TryGetQuality(ingested, out qc);
                if (((int)qc) == 0)
                {
                    num = this.severity / 2;
                } else if (((int)qc) == 1) 
                {
                    num = this.severity;
                }else if ((((int)qc) > 1) && (((int)qc) < 6))
                {
                    num = this.severity * (int)qc;
                }else if (((int)qc) == 6)
                {
                    num = this.severity * 10;
                }
            }
            hediff.Severity = num;
            pawn.health.AddHediff(hediff, null, null, null);
        }

        // Token: 0x06004AB2 RID: 19122 RVA: 0x0019BB16 File Offset: 0x00199D16
        public override IEnumerable<StatDrawEntry> SpecialDisplayStats(ThingDef parentDef)
        {
            if (parentDef.IsDrug && this.chance >= 1f)
            {
                foreach (StatDrawEntry statDrawEntry in this.hediffDef.SpecialDisplayStats(StatRequest.ForEmpty()))
                {
                    yield return statDrawEntry;
                }
                IEnumerator<StatDrawEntry> enumerator = null;
            }
            yield break;
            yield break;
        }

        // Token: 0x04002996 RID: 10646
        public HediffDef hediffDef;

        // Token: 0x04002997 RID: 10647
        public float severity = -1f;

        // Token: 0x04002998 RID: 10648
        public ChemicalDef toleranceChemical;

        // Token: 0x04002999 RID: 10649
        private bool divideByBodySize;
    }
}