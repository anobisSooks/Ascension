﻿using RimWorld;
using Verse;

namespace Ascension
{
    [DefOf]
    public static class AscensionDefOf
    {
        public static Verse.HediffDef SpiritSwordFusion;
        public static HediffDef PseudoImmortality;
        public static HediffDef AscendantFoundation;

        //static AscensionDefOf()
        //{
        //    DefOfHelper.EnsureInitializedInCtor(typeof(AscensionDefOf));
        //}
    }
}